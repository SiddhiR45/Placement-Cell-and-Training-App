package com.example.project_patt.Fragment;

import static java.nio.file.Files.find;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project_patt.Add_job;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.project_patt.R;

import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import kotlinx.coroutines.Job;


public class AddJobFragment extends Fragment {
    private Spinner locationSpinner;
    private EditText jobNameEditText, jobLocationEditText, companyNameEditText, salaryEditText;
    private Button addButton;

    private DatabaseReference databaseReference;

    private void populateSpinner() {
        // Dummy job options
        List<String> jobOptions = new ArrayList<>();
        jobOptions.add("Select Job"); // hint
        jobOptions.add("Software Developer");
        jobOptions.add("Data Scientist");
        jobOptions.add("Project Manager");
        jobOptions.add("UX/UI Designer");
        jobOptions.add("Business Analyst");

        // Create adapter for Spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(requireContext(), android.R.layout.simple_spinner_item, jobOptions) {
            @Override
            public boolean isEnabled(int position) {
                // Disable the hint item
                return position != 0;
            }

            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView textView = (TextView) view;
                if (position == 0) {
                    // Set the hint text color to grey
                    textView.setTextColor(Color.GRAY);
                } else {
                    textView.setTextColor(Color.BLACK);
                }
                return view;
            }
        };

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Set adapter to Spinner
        locationSpinner.setAdapter(spinnerAdapter);
    }




        @SuppressLint("WrongViewCast")
        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_addjob, container, false);

            // Initialize Spinner
            locationSpinner = view.findViewById(R.id.job_spinner);

            // Populate Spinner with job options
            populateSpinner();

            // Initialize Firebase database reference
            databaseReference = FirebaseDatabase.getInstance().getReference("jobs");

            // Initialize views

            jobLocationEditText = view.findViewById(R.id.loc_edittext);
            companyNameEditText = view.findViewById(R.id.compname_edittext);
            salaryEditText = view.findViewById(R.id.sal_edittext);

            addButton = view.findViewById(R.id.upload_button);

            // Set OnClickListener for the add button
            addButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    addJob();
                }
            });

            return view;
        }

    private void addJob() {
        String jobLocation = jobLocationEditText.getText().toString().trim();
        String companyName = companyNameEditText.getText().toString().trim();
        String salary = salaryEditText.getText().toString().trim();

        // Get the selected job from the spinner
        String selectedJob = locationSpinner.getSelectedItem().toString();

        if (selectedJob.equals("Select Job")) {
            Toast.makeText(getContext(), "Please select a job", Toast.LENGTH_SHORT).show();
            return; // Exit the method if no job is selected
        }

        if (!jobLocation.isEmpty() && !companyName.isEmpty() && !salary.isEmpty()) {
            // Generate a unique key for the job
            String jobId = databaseReference.push().getKey();

            // Create a Job object
          //  Add_job job = new Add_job(jobId, selectedJob, jobLocation, companyName, salary);
            Add_job job = new Add_job(jobId, selectedJob, companyName, salary, jobLocation);

            // Upload the job to Firebase
            databaseReference.child(jobId).setValue(job)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getContext(), "Job added successfully", Toast.LENGTH_SHORT).show();
                                // Clear input fields
                                jobLocationEditText.setText("");
                                companyNameEditText.setText("");
                                salaryEditText.setText("");
                            } else {
                                Toast.makeText(getContext(), "Failed to add job", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        } else {
            Toast.makeText(getContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
        }
    }

}
