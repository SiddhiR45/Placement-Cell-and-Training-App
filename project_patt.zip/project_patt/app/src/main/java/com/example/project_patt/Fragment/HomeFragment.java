package com.example.project_patt.Fragment;

import static android.content.ContentValues.TAG;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Timer;
import android.os.Handler;

import com.example.project_patt.Add_job;
import com.example.project_patt.JobAdapter;
import com.example.project_patt.JobAdapter1;
import com.example.project_patt.R;
import com.example.project_patt.SlideAdapter;
import com.example.project_patt.jobmodel;
import com.example.project_patt.jobmodel1;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.TimerTask;

public class HomeFragment extends Fragment {
    // job
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter1;
    private RecyclerView recyclerView1;
    private RecyclerView.Adapter adapter2;

    private DatabaseReference databaseReference;
    private List<Add_job> jobList = new ArrayList<>(); // Initialize jobList

    // advertisement
    private ViewPager viewPager;
    private int currentPage = 0;
    private Timer timer;
    final long delay = 5000;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_homefragment, container, false);

        // recyclerview logic
        recyclerView = view.findViewById(R.id.jobs);
        LinearLayoutManager layoutManager1 = new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(layoutManager1);
        adapter1 = new JobAdapter(requireContext(), getCategoryList());
        recyclerView.setAdapter(adapter1);

        // recyclerview2
        recyclerView1 = view.findViewById(R.id.jobs1);
        LinearLayoutManager layoutManager2 = new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView1.setLayoutManager(layoutManager2);
        adapter2 = new JobAdapter1(requireContext(), getCategoryList1());
        recyclerView1.setAdapter(adapter2);

        databaseReference = FirebaseDatabase.getInstance().getReference("jobs");

        // Attach a listener to read the data
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                jobList.clear(); // Clear the list before adding new data
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Add_job job = snapshot.getValue(Add_job.class);
                    jobList.add(job);
                }
                adapter2.notifyDataSetChanged(); // Notify adapter about data change
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException());
            }
        });

        // viewpager logic
        viewPager = view.findViewById(R.id.adv);
        SlideAdapter viewPagerAdapter = new SlideAdapter(getActivity());
        viewPager.setAdapter(viewPagerAdapter);

        // Set up a timer to auto-scroll the ViewPager
        final Handler handler = new Handler();
        final Runnable update = new Runnable() {
            public void run() {
                if (currentPage == viewPagerAdapter.getCount()) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(update);
            }
        }, delay, delay);

        return view;
    }

    // displaying the job in recyclerview
    private ArrayList<jobmodel> getCategoryList() {
        ArrayList<jobmodel> categoryList = new ArrayList<>();
        categoryList.add(new jobmodel("IT / Hardware", R.drawable.it));
        categoryList.add(new jobmodel("Mechanical Engineer", R.drawable.mechanical));
        categoryList.add(new jobmodel("Customer Service", R.drawable.customers));
        // Add more categories here
        return categoryList;
    }

    private List<Add_job> getCategoryList1() {
        List<Add_job> list = new ArrayList<>();
        list.add(new Add_job("1","IT professional", "₹15000-₹20000", "Scymes Services Pvt. Ltd", "Santacruz(East),Mumbai"));
        list.add(new Add_job("2","Computer Operator", "₹9500-₹10500", "Prodocs Solutions Pvt. Ltd", "Marol,Mumbai"));
        list.add(new Add_job("3","IT professional", "₹35000-₹40000", "Smart Consulting", "Andheri(East),Mumbai"));
        // Add more job details here
        return list;
    }
}