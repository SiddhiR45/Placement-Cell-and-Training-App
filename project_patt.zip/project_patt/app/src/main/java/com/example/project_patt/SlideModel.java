package com.example.project_patt;

public class SlideModel {
}
