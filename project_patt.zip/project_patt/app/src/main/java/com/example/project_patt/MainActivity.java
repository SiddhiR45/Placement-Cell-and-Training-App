package com.example.project_patt;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.project_patt.Fragment.HomeFragment;
import com.example.project_patt.Fragment.JobsFragment;
import com.example.project_patt.Fragment.MessageFragment;
import com.example.project_patt.Fragment.ProfileFragment;
import com.example.project_patt.Fragment.StudyFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

            if (item.getItemId() == R.id.homefragment) {
                selectedFragment = new HomeFragment();
            } else if (item.getItemId() == R.id.jobsFragment) {
                selectedFragment = new JobsFragment();
            } else if (item.getItemId() == R.id.messageFragment) {
                selectedFragment = new MessageFragment();
            } else if (item.getItemId() == R.id.studyFragment) {
                selectedFragment = new StudyFragment();
            }else if (item.getItemId() == R.id.profileFragment) {
                selectedFragment = new ProfileFragment();
            }

            loadFragment(selectedFragment);
            return true;
        });


        // Set the default selected item
        bottomNavigation.setSelectedItemId(R.id.homefragment);
    }
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}

