package com.example.project_patt;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class JobAdapter1 extends RecyclerView.Adapter<JobAdapter1.ViewHolder> {
    private List<Add_job> items; // List to hold both categories and job details
    private Context context;

    public JobAdapter1(Context context, List<Add_job> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_jobs1, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Add_job item = items.get(position);

        if (item instanceof Add_job) {
            // Handle job details
            Add_job job = (Add_job) item;
            holder.jobNameTextView.setText(job.getJobName());
            holder.companyNameTextView.setText(job.getCompanyName());
            holder.salaryTextView.setText(job.getSalary());
            holder.locationTextView.setText(job.getLocation());
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView categoryName1;
        public TextView categorySalary;
        public TextView categoryComname;
        public TextView categoryLocation;
        public TextView jobNameTextView, companyNameTextView, salaryTextView, locationTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            categoryName1 = itemView.findViewById(R.id.jobname1);
            categorySalary = itemView.findViewById(R.id.salary);
            categoryComname = itemView.findViewById(R.id.comname);
            categoryLocation = itemView.findViewById(R.id.location);
            jobNameTextView = itemView.findViewById(R.id.jobname1);
            companyNameTextView = itemView.findViewById(R.id.salary);
            salaryTextView = itemView.findViewById(R.id.comname);
            locationTextView = itemView.findViewById(R.id.location);
        }
    }
}

