package com.example.project_patt.Fragment;

public class ReadWriteUserDetails {
    public String dob,gender,mobile;
    public ReadWriteUserDetails(){};
    public ReadWriteUserDetails(String textdob,String textGender,String textMobile){
        this.dob=textdob;
        this.gender=textGender;
        this.mobile=textMobile;
    }
}
