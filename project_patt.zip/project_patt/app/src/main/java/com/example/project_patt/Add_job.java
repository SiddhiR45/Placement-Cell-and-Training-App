package com.example.project_patt;

public class Add_job {
    private String jobId;
    private String jobName;
    private String companyName;
    private String salary;
    private String location;

    public Add_job() {
        // Default constructor required for calls to DataSnapshot.getValue(Job.class)
    }

    public Add_job(String jobId, String jobName, String companyName, String salary, String location) {
        this.jobId = jobId;
        this.jobName = jobName;
        this.companyName = companyName;
        this.salary = salary;
        this.location = location;
    }

    public String getJobId() {
        return jobId;
    }

    public String getJobName() {
        return jobName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getSalary() {
        return salary;
    }

    public String getLocation() {
        return location;
    }
}
